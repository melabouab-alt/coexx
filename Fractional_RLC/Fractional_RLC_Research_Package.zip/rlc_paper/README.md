# Fractional RLC paper and reproduction files

Author: Fatema Alzahraa Ahmed Elshareef

Affiliation: Department of Electrical Engineering, University of Tripoli

`Fractional_RLC_IEEE_6_Pages.pdf` is the final English paper: six US Letter pages in the IEEEtran conference two-column layout with the requested blue styling. Its abstract contains exactly 100 words, excluding the Abstract label. It has five numbered references, five figures including the circuit diagram, three result tables, a separate conclusion, and MATLAB code in Appendix A. The findings describe numerical simulations of a specified generalized element model, not hardware measurements.

## MATLAB

Run `results = rlc_fractional_study;` from the folder containing `rlc_fractional_study.m`. This full function exports curves, validation, metrics, and state data into `matlab_results`. No optional toolbox is needed. `rlc_demo.m` is the compact script printed in the paper; it produces voltage/current and magnitude curves. See `README_matlab.md` for units and execution details.

MATLAB was unavailable during preparation. The MATLAB files were independently reviewed statically. The reported results were computed with the equivalent Python recurrence, verified against an exact classical solution and independent 35-digit de Hoog inverse Laplace calculations. No native MATLAB execution is claimed.

## Editable paper and exact reproduction

The `source` folder contains the LaTeX paper, the unmodified official IEEEtran V1.8b class, tables, vector PDF figures, PNG previews, and `simulation.py`. The author and affiliation are already set to Fatema Alzahraa Ahmed Elshareef, Department of Electrical Engineering, University of Tripoli.

To regenerate the numerical study, install the four packages in `source/requirements.txt`, then run `python source/simulation.py`. This regenerates figures and metrics beside the script. The numerical tables are already saved as LaTeX and as CSV files under `data`.

To build the PDF, change to `source` and run `pdflatex -interaction=nonstopmode -halt-on-error paper.tex` twice. The paper requires standard LaTeX packages, including circuitikz, mathtools, listings, microtype, and balance. The provided figures permit compilation without running Python.

`data` contains the full numerical state records (.npz), reported metrics, validation errors, and a JSON record of the independent reference values. The main physical time step is 2.5 microseconds and the horizon is 60 ms. Settling times are finite-horizon last-exit estimates, with linearly interpolated crossings.

## Referenced starting paper

A. Moazzam et al., “Applications of Fractional-Laplace Transformation in the Field of Electrical Engineering,” Journal of Kufa for Mathematics and Computer, 10(2), 70–75, 2023.

Publisher: https://journal.uokufa.edu.iq/index.php/jkmc/article/view/12370

The new paper distinguishes the starting paper's reparameterized Laplace kernel from a physical Caputo fractional circuit model. This is an independently derived course-level contribution, not a claim of new circuit hardware or a new general theorem.
