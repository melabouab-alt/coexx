"""Reproducible full-history backward-Euler convolution quadrature RLC study.

No measurement data are used. Dimensionless Caputo state equations:
D^alpha x=y, D^alpha y=-x-y+1; zero initial conditions.
Physical scaling: t=tau*u, v=V0*x, i=(V0/Z0)*y.
"""
import os
from pathlib import Path
os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / "mplcache"))
os.environ.setdefault("XDG_CACHE_HOME", str(Path(__file__).resolve().parent / ".cache"))
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '1'
import json
import time
from pathlib import Path
import numpy as np
import scipy.optimize as so
import scipy.special as ss
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
import mpmath as mp

ROOT = Path(__file__).resolve().parent
FIG = ROOT / 'figures'
FIG.mkdir(exist_ok=True)
TAU = 1e-3
V0 = 1.
Z0 = 10.
U = 60.
H = 0.0025
ALPHAS = (0.8, 0.9, 1.0)
GRIDS = (0.01, 0.005, 0.0025)
A = np.array([[0.,1.],[-1.,-1.]])
b = np.array([0.,1.])


def solve(alpha, h, umax=U):
    nmax = int(round(umax/h))
    w = np.empty(nmax+1)
    w[0] = 1.
    for j in range(1, nmax+1):
        w[j] = (1.-(alpha+1.)/j)*w[j-1]
    z = np.zeros((2, nmax+1))
    h_alpha = h**alpha
    M = np.linalg.inv(np.eye(2)-h_alpha*A)
    rhs_source = h_alpha*b
    for n in range(1, nmax+1):
        # Direct summation; no truncated memory and no rational approximation.
        memory = np.einsum('ij,j->i', z[:, :n], w[n:0:-1], optimize=False)
        z[:, n] = M @ (rhs_source-memory)
    return np.arange(nmax+1)*h, z


def classical(u):
    wd = np.sqrt(3.)/2.
    x = 1.-np.exp(-u/2.)*(np.cos(wd*u)+np.sin(wd*u)/np.sqrt(3.))
    y = 2./np.sqrt(3.)*np.exp(-u/2.)*np.sin(wd*u)
    return np.vstack([x,y])


def first_crossing(t, values, level):
    idxs = np.flatnonzero(values >= level)
    if not len(idxs):
        return None
    n = int(idxs[0])
    if n == 0:
        return float(t[0])
    return float(t[n-1]+(level-values[n-1])*(t[n]-t[n-1])/(values[n]-values[n-1]))


def last_exit(t, x, tol):
    err = np.abs(x-1.)
    outside = np.flatnonzero(err > tol)
    if not len(outside):
        return {'sampled_ms':0., 'interpolated_ms':0., 'last_outside_index':None}
    n = int(outside[-1])
    if n == len(t)-1:
        return {'sampled_ms':None, 'interpolated_ms':None, 'last_outside_index':n}
    # Absolute error is locally monotone across this final threshold crossing.
    ti = t[n]+(tol-err[n])*(t[n+1]-t[n])/(err[n+1]-err[n])
    return {'sampled_ms':float(t[n+1]), 'interpolated_ms':float(ti), 'last_outside_index':n}


def freq_response(alpha, f):
    s = 1j*2.*np.pi*np.asarray(f)*TAU
    return 1./(s**(2.*alpha)+s**alpha+1.)


def frequency_metrics(alpha):
    # Exact real polynomial in q=(omega*tau)^alpha for |denominator|^2.
    c = np.cos(alpha*np.pi/2.)
    roots = np.roots([4.,6.*c,2.*(4.*c*c-1.),2.*c])
    extrema = []
    for qr in roots:
        if abs(qr.imag) < 1e-8 and qr.real > 1e-9:
            q = float(qr.real)
            f = q**(1./alpha)/(2.*np.pi*TAU)
            gain = float(np.abs(freq_response(alpha,f)))
            second = 12.*q*q+12.*c*q+2.*(4.*c*c-1.)
            extrema.append({'f_hz':f,'gain':gain,'gain_db':20.*np.log10(gain),
                            'response_kind':'local maximum' if second>0 else 'local minimum'})
    peak = [e for e in extrema if e['response_kind']=='local maximum' and e['gain']>1.+1e-9]
    return {'above_unity_resonance':peak[0] if peak else None,
            'stationary_extrema':sorted(extrema,key=lambda e:e['f_hz']),
            'dc_gain':1.}


def metrics(alpha, u, z):
    x,y = z
    # u has the same numerical value as t in milliseconds because tau=1 ms.
    imax = int(np.argmax(x))
    overshoot = max(0., float(x[imax]-1.))*100.
    t10, t90 = first_crossing(u,x,.1), first_crossing(u,x,.9)
    n30 = int(round(30./H))
    tail_sel = u >= 50.
    return {
        'overshoot_percent_0_60ms':overshoot,
        'peak_time_ms':float(u[imax]) if overshoot>0. else None,
        'maximum_voltage_v_0_60ms':float(x[imax]),
        'rise_10_90_ms':float(t90-t10),
        't10_ms':t10,'t90_ms':t90,
        'settling_2pct':last_exit(u,x,.02),
        'settling_1pct':last_exit(u,x,.01),
        'x30':float(x[n30]),'y30':float(y[n30]),
        'x60':float(x[-1]),'y60':float(y[-1]),
        'i30_A':float(y[n30]*V0/Z0),
        'i60_A':float(y[-1]*V0/Z0),
        'observed_max_abs_error_50_60ms':float(np.max(np.abs(x[tail_sel]-1.))),
        'leading_asymptotic_deficit_30ms':float(30.**(-alpha)/ss.gamma(1.-alpha)) if alpha<1 else None,
        'leading_asymptotic_deficit_60ms':float(60.**(-alpha)/ss.gamma(1.-alpha)) if alpha<1 else None,
        'frequency':frequency_metrics(alpha),
    }


def inverse_values(alpha, times):
    mp.mp.dps = 35
    aa = mp.mpf(str(alpha))
    xv,yv = [],[]
    for ti in times:
        t = mp.mpf(str(ti))
        xv.append(float(mp.invertlaplace(lambda s:1./(s*(s**(2*aa)+s**aa+1)),t,method='dehoog')))
        yv.append(float(mp.invertlaplace(lambda s:s**(aa-1)/(s**(2*aa)+s**aa+1),t,method='dehoog')))
    return np.array([xv,yv])


def figure_style():
    plt.rcParams.update({
        'font.family':'serif','font.serif':['DejaVu Serif'],
        'font.size':8.,'axes.labelsize':8.,'axes.titlesize':8.,
        'legend.fontsize':7.5,'xtick.labelsize':7.5,'ytick.labelsize':7.5,
        'lines.linewidth':1.25,'axes.linewidth':.6,
        'pdf.fonttype':42,'ps.fonttype':42,
        'savefig.bbox':'tight','savefig.pad_inches':.025,
    })


def plots(results, validation):
    figure_style()
    colors = ['#1769A5','#D26719','#303030']
    styles = ['-','--',':']
    # Physical transient: enough temporal detail for peak and early dynamics.
    fig,ax = plt.subplots(2,1,figsize=(3.5,3.35),sharex=True,layout='constrained')
    for a,col,ls in zip(ALPHAS,colors,styles):
        u,z = results[a]
        sel = u <= 12.
        ax[0].plot(u[sel],z[0,sel],color=col,ls=ls,label=rf'$\alpha={a:.1f}$')
        ax[1].plot(u[sel],1000.*V0/Z0*z[1,sel],color=col,ls=ls)
    ax[0].axhline(1.,color='#808080',lw=.6)
    ax[0].set_ylabel('Capacitor voltage (V)')
    ax[0].legend(loc='lower right',frameon=False,ncol=1)
    ax[0].set_ylim(0,1.22)
    ax[1].set_ylabel('Series current (mA)')
    ax[1].set_xlabel('Time (ms)')
    ax[1].set_xlim(0,12)
    for aa in ax: aa.grid(True,alpha=.22,lw=.45)
    fig.savefig(FIG/'transient.pdf')
    fig.savefig(FIG/'transient.png',dpi=220)
    plt.close(fig)
    # Signed voltage error shows both settling thresholds and algebraic tails.
    fig,ax = plt.subplots(figsize=(3.5,2.55),layout='constrained')
    for a,col,ls in zip(ALPHAS,colors,styles):
        u,z = results[a]
        sel = u >= 5.
        ax.plot(u[sel],100.*(z[0,sel]-1.),color=col,ls=ls,label=rf'$\alpha={a:.1f}$')
    for band in (-2.,2.): ax.axhline(band,color='#787878',lw=.6,ls='--')
    for band in (-1.,1.): ax.axhline(band,color='#A0A0A0',lw=.55,ls=':')
    ax.axhline(0.,color='#B0B0B0',lw=.5)
    ax.set_xlabel('Time (ms)')
    ax.set_ylabel('Voltage error (%)')
    ax.set_xlim(5,60)
    ax.set_ylim(-5.5,9.)
    ax.set_xticks([5,15,30,45,60])
    ax.legend(loc='upper right',frameon=False,ncol=3)
    ax.grid(True,alpha=.22,lw=.45)
    fig.savefig(FIG/'tail.pdf')
    fig.savefig(FIG/'tail.png',dpi=220)
    plt.close(fig)
    f=np.logspace(0,4,1200)
    fig,ax=plt.subplots(2,1,figsize=(3.5,3.35),sharex=True,layout='constrained')
    for a,col,ls in zip(ALPHAS,colors,styles):
        response=freq_response(a,f)
        ax[0].semilogx(f,20.*np.log10(np.abs(response)),color=col,ls=ls,label=rf'$\alpha={a:.1f}$')
        ax[1].semilogx(f,np.angle(response,deg=True),color=col,ls=ls)
    ax[0].set_ylabel('Magnitude (dB)')
    ax[0].legend(frameon=False,loc='lower left',ncol=1)
    ax[1].set_ylabel('Phase (deg)')
    ax[1].set_xlabel('Frequency (Hz)')
    ax[0].set_ylim(-75,5)
    ax[1].set_ylim(-185,5)
    ax[1].set_yticks([0,-45,-90,-135,-180])
    ax[1].set_xlim(1,10000)
    for aa in ax: aa.grid(True,which='both',alpha=.22,lw=.45)
    fig.savefig(FIG/'frequency.pdf')
    fig.savefig(FIG/'frequency.png',dpi=220)
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(3.5,2.55),layout='constrained')
    for a,col,ls in zip(ALPHAS,colors,styles):
        errors=[validation[str(a)]['grid_results'][str(h)]['independent_max_x_error'] for h in GRIDS]
        ax.loglog(GRIDS,errors,marker='o',markersize=3.8,color=col,ls=ls,label=rf'$\alpha={a:.1f}$')
    e_ref = validation['0.8']['grid_results']['0.01']['independent_max_x_error']*1.3
    ax.loglog(GRIDS, e_ref*np.array(GRIDS)/.01,color='#808080',ls='-.',lw=.8,label=r'$O(h)$ guide')
    ax.set_xlabel('Dimensionless time step h')
    ax.set_ylabel('Max. sampled voltage error')
    ax.set_xticks([.0025,.005,.01],labels=['0.0025','0.005','0.01'])
    ax.set_xlim(.0022,.0115)
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.grid(True,which='both',alpha=.22,lw=.45)
    ax.legend(frameon=False,loc='upper left',fontsize=7.,ncol=1)
    fig.savefig(FIG/'convergence.pdf')
    fig.savefig(FIG/'convergence.png',dpi=220)
    plt.close(fig)


def main():
    start=time.time()
    results={}
    grids={}
    out={'model':{'A':A.tolist(),'b':b.tolist(),'initial_state':[0.,0.],
                  'tau_seconds':TAU,'Z0_ohm':Z0,'V0_volts':V0,'U':U,'main_h':H,
                  'method':'Full-history backward-Euler convolution quadrature',
                  'step_settling_note':'Last exit from a tolerance band, with linear interpolation; checked only through 60 ms.',
                  'observed_tail_note':'Maximum error over 50-60 ms is a numerical finite-window bound, not a global analytic bound.',
                  'asymptotic_tail_note':'Leading term u^(-alpha)/Gamma(1-alpha), an estimate and not a rigorous bound.'},
         'metrics':{},'validation':{}}
    check_times=[.25,1.,2.,4.,10.,20.,30.,60.]
    for a in ALPHAS:
        print(f'alpha={a}: solving grids',flush=True)
        grids[a]={}
        for h in GRIDS:
            u,z=solve(a,h)
            grids[a][h]=(u,z)
        results[a]=grids[a][H]
        out['metrics'][str(a)]=metrics(a,*results[a])
        print(f'alpha={a}: independent inversion',flush=True)
        independent=inverse_values(a,check_times)
        validation={'independent_method':'mpmath de Hoog inverse Laplace, 35 decimal digits',
                    'check_times_ms':check_times,'independent_x':independent[0].tolist(),
                    'independent_y':independent[1].tolist(),'grid_results':{}}
        for h in GRIDS:
            u,z=grids[a][h]
            inds=np.rint(np.array(check_times)/h).astype(int)
            errors=np.abs(z[:,inds]-independent)
            validation['grid_results'][str(h)]={
                'independent_max_x_error':float(np.max(errors[0])),
                'independent_max_y_error':float(np.max(errors[1])),
                'independent_x_errors':errors[0].tolist(),
                'independent_y_errors':errors[1].tolist(),
            }
            if a==1.:
                exact=classical(u)
                validation['grid_results'][str(h)].update({
                    'classical_max_x_error_all_times':float(np.max(np.abs(z[0]-exact[0]))),
                    'classical_max_y_error_all_times':float(np.max(np.abs(z[1]-exact[1])))})
        deltas=[]
        for coarse,fine in zip(GRIDS[:-1],GRIDS[1:]):
            coarse_z=grids[a][coarse][1]
            fine_z=grids[a][fine][1][:,::2]
            diffs=np.max(np.abs(coarse_z-fine_z),axis=1)
            deltas.append({'coarse_h':coarse,'fine_h':fine,'max_x_difference':float(diffs[0]),
                           'max_y_difference':float(diffs[1])})
        validation['self_convergence']=deltas
        validation['self_convergence_order_x']=float(np.log2(deltas[0]['max_x_difference']/deltas[1]['max_x_difference']))
        validation['independent_order_x']=float(np.log2(validation['grid_results']['0.005']['independent_max_x_error']/validation['grid_results']['0.0025']['independent_max_x_error']))
        out['validation'][str(a)]=validation
        print(json.dumps(out['metrics'][str(a)],indent=2),flush=True)
    out['runtime_seconds_before_plots']=time.time()-start
    (ROOT/'metrics.json').write_text(json.dumps(out,indent=2)+'\n')
    for a,(u,z) in results.items():
        np.savez_compressed(ROOT/f'response_alpha_{a:.1f}.npz',u=u,x=z[0],y=z[1])
    plots(results,out['validation'])
    print(f'Complete: {time.time()-start:.2f} s',flush=True)

if __name__=='__main__':
    main()
